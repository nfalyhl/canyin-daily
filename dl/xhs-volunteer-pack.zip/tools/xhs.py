# -*- coding: utf-8 -*-
"""小红书采集：用你本机的真实 Edge（带窗口）+ CDP，扫码登录一次后即可按关键词抓笔记。

为什么这样做：
  · 小红书必须登录才能看搜索结果（未登录只有登录弹窗）
  · 无头浏览器会被风控直接判「IP存在风险」，必须用真实窗口
    （默认起真实 Edge 窗口，起来后自动最小化 → 进程是真窗口，你看不到它）
  · 小红书域名必须走直连：Clash 里给 xiaohongshu.com / *.xhscdn.com 加 DIRECT，
    走代理 = 机房出口 IP，必被拦
  · 用 CDP 连接真实 Edge，比 Playwright 自带的 Chromium 不容易被滑块拦
  · 浏览器 profile 单独一份（默认 %LOCALAPPDATA%\\canyin-daily\\xhs-profile），与你的日常浏览器互不影响

用法：
    python tools/xhs.py login                 # 弹窗口，用小红书 App 扫码；登录后自动保存并退出
    python tools/xhs.py check                 # 看当前 profile 是否已登录
    python tools/xhs.py status                # 输出 JSON 状态（登录/未登录/风控），给网页用
    python tools/xhs.py logout                # 清掉登录态（换号用）
    python tools/xhs.py search --keywords "餐饮新品,茶饮新品" --days 10 \
        --out public/data/xhs-notes.json      # 抓笔记（供 daily.py 当数据源用）
    注意：search 默认**未登录/被风控就不采集**，并把状态写进 public/data/xhs-status.json
"""
from __future__ import annotations

import argparse
import json
import os
import random
import re
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

try:
    import websocket
except ImportError:
    print("需要 websocket-client：python -m pip install -i https://mirrors.aliyun.com/pypi/simple/ websocket-client")
    sys.exit(1)

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
ROOT = Path(__file__).resolve().parent.parent
EDGE_CANDIDATES = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]
DEFAULT_PROFILE = Path(os.environ.get("LOCALAPPDATA", str(ROOT))) / "canyin-daily" / "xhs-profile"
SEARCH_URL = "https://www.xiaohongshu.com/search_result?keyword={kw}&type=51"
STATUS_FILE = ROOT / "public" / "data" / "xhs-status.json"


def write_status(state: str, **extra) -> None:
    """把采集/登录状态写成一个固定文件，网页那边读它就知道「现在能不能采集」。

    state 取值：ok / need_login / risk / error / logged_out / running
    """
    payload = {"state": state, "at": datetime.now().isoformat(timespec="seconds"), **extra}
    try:
        STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATUS_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=1),
                               encoding="utf-8")
    except Exception:
        pass

# 页面上每张笔记卡片里能拿到的字段
EXTRACT_JS = r"""
(function () {
  function txt(sel, root) { var e = (root || document).querySelector(sel); return e ? (e.innerText || '').trim() : ''; }
  var out = [];
  document.querySelectorAll('section.note-item').forEach(function (el) {
    var a = el.querySelector('a.cover') || el.querySelector('a[href*="/explore/"]') ||
            el.querySelector('a[href*="/search_result/"]');
    if (!a) return;
    out.push({
      title: txt('.title span', el) || txt('.title', el),
      author: txt('.author .name', el) || txt('.author-wrapper .name', el),
      like: txt('.like-wrapper .count', el) || txt('.count', el),
      url: a.href
    });
  });
  return JSON.stringify(out);
})()
"""


def hide_window(pid: int) -> int:
    """把某个进程的所有可见顶层窗口从桌面/任务栏彻底隐藏（ShowWindow SW_HIDE）。

    为什么要这个：二维码必须由**真实浏览器**生成（--headless 会被小红书判「安全限制」，
    实测过），但用户没必要看见那个窗口，连任务栏图标都不该出现 —— 二维码会回传到网页
    里给用户扫。SW_HIDE 后窗口依然真实存在（Chrome 仍认为是真窗口），只是不可见。

    返回隐藏掉的窗口数。
    """
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return 0
    user32 = ctypes.windll.user32
    hidden = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def _cb(hwnd, _lparam):
        wpid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(wpid))
        if wpid.value == pid and user32.IsWindowVisible(hwnd):
            user32.ShowWindow(hwnd, 0)   # SW_HIDE
            hidden.append(hwnd)
        return True

    user32.EnumWindows(_cb, 0)
    return len(hidden)


def find_edge() -> str:
    for p in EDGE_CANDIDATES:
        if Path(p).exists():
            return p
    raise SystemExit("没找到 msedge.exe")


class Xhs:
    """驱动本机 Edge 打开小红书页面的最小封装（CDP）。"""

    def __init__(self, profile: Path = DEFAULT_PROFILE, port: int = 9333,
                 headless: bool = False, wait_ready: float = 25.0,
                 minimized: bool = False):
        self.port, self.profile = port, profile
        self.profile.mkdir(parents=True, exist_ok=True)
        args = [find_edge()]
        if headless:
            args.append("--headless=new")
        args += [f"--remote-debugging-port={port}", f"--user-data-dir={profile}",
                 "--remote-allow-origins=*", "--no-first-run", "--no-default-browser-check",
                 "--lang=zh-CN", "--window-size=1200,880",
                 # 把窗口开到**屏幕外**（负坐标）：二维码必须由真实浏览器生成（无头会被
                 # 小红书判「安全限制」，实测过），但用户没必要看见它 —— 二维码会回传到
                 # 网页里给用户扫。这样点「扫码登录」时，用户电脑上不会再冒出一个窗口。
                 "--window-position=-32000,-32000",
                 "about:blank"]
        self.proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.ws, self.mid, self._id = None, 0, None
        t0 = time.time()
        while time.time() - t0 < wait_ready:
            try:
                tabs = self._http("/json/list")
                pages = [t for t in tabs if t.get("type") == "page"]
                if pages:
                    self._id = pages[0]["id"]
                    self.ws = websocket.create_connection(pages[0]["webSocketDebuggerUrl"],
                                                          timeout=30, suppress_origin=True)
                    break
            except Exception:
                time.sleep(0.4)
        if not self.ws:
            raise RuntimeError("连不上 Edge 调试端口（可能有别的实例占着 profile）")
        self.send("Page.enable")
        self.send("Runtime.enable")
        self.send("Network.enable")
        if minimized and not headless:
            self.minimize()
            # 再彻底隐藏：连任务栏都不出现（minimize 仍会在任务栏留一个图标）
            n = hide_window(self.proc.pid)
            self.hidden_windows = n

    def minimize(self) -> bool:
        """最小化采集窗口。

        关键点：这仍然是「真实可见窗口」（不是 --headless），只是被最小化了 ——
        风控看的是「有没有真实浏览器进程/窗口」，不是「窗口在不在前台」。
        """
        try:
            r = self.send("Browser.getWindowForTarget", {"targetId": self._id})
            wid = ((r.get("result") or {}) if isinstance(r, dict) else {}).get("windowId")
            if wid is None:
                return False
            self.send("Browser.setWindowBounds",
                      {"windowId": wid, "bounds": {"windowState": "minimized"}})
            return True
        except Exception:
            return False

    def _http(self, path: str):
        return json.loads(urllib.request.urlopen(
            f"http://127.0.0.1:{self.port}{path}", timeout=8).read())

    def send(self, method: str, params: dict | None = None, timeout: float = 30):
        self.mid += 1
        self.ws.settimeout(timeout)
        self.ws.send(json.dumps({"id": self.mid, "method": method, "params": params or {}}))
        while True:
            m = json.loads(self.ws.recv())
            if m.get("id") == self.mid:
                return m

    def js(self, expr: str):
        return (self.send("Runtime.evaluate",
                          {"expression": expr, "returnByValue": True, "awaitPromise": True})
                .get("result", {}).get("result", {}).get("value"))

    def goto(self, url: str, wait: float = 5.0) -> bool:
        """导航到 url；返回是否导航成功。

        实测：无头 Edge 刚起来时的**第一次**真导航会一直卡到 CDP 超时（30s 也等不到
        Page.navigate 的回包），同样的 URL 第二次只要 0.2s。以前这里不重试，异常直接
        抛出去，把整条流程（扫码、采集）炸成静默失败 —— 所以超时要重试一次。
        """
        ok = False
        for attempt, tmo in ((1, 20), (2, 45)):
            try:
                self.send("Page.navigate", {"url": url}, timeout=tmo)
                ok = True
                break
            except Exception as e:
                print(f"   ! 导航超时（第 {attempt} 次）：{type(e).__name__}", file=sys.stderr)
                time.sleep(1.5)
        time.sleep(wait)
        return ok

    def risk_reason(self) -> str:
        """当前页是不是风控/异常页？是就返回原因，正常返回 ''。

        小红书拦人不一定弹窗：实测直接给一张标题为「安全限制」的极简页（正文 41 字）。
        旧代码只看正文里有没有「IP存在风险」，会把这种页面当成「没弹窗 = 已登录」。
        """
        try:
            title = str(self.js("document.title") or "")
            body = str(self.js("document.body ? document.body.innerText : ''") or "")
        except Exception as e:
            return f"读不到页面内容（{type(e).__name__}）"
        blob = title + "\n" + body
        for kw in ("安全限制", "IP存在风险", "300012", "访问受限", "操作过于频繁"):
            if kw in blob:
                return f"小红书返回风控页（标题「{title[:20]}」，命中「{kw}」）"
        if len(body.strip()) < 200:
            return f"页面没正常加载（正文只有 {len(body)} 字，标题「{title[:20]}」）"
        return ""

    def cookies(self) -> dict:
        r = self.send("Network.getCookies", {"urls": ["https://www.xiaohongshu.com"]})
        out = {}
        for c in (r.get("result", {}) or {}).get("cookies", []) or []:
            out[c.get("name")] = c.get("value")
        return out

    def grab_qr(self) -> str:
        """取登录二维码。小红书页面上就是 <img class="qrcode-img" src="data:image/png;base64,...">，
        直接用它的 src，比截图更清晰。"""
        src = self.js("""(function(){
          var el = document.querySelector('img.qrcode-img') ||
                   document.querySelector('.qrcode img') ||
                   document.querySelector('[class*=qrcode] img');
          return el && el.src ? el.src : '';
        })()""")
        if isinstance(src, str) and src.startswith("data:image"):
            return src
        # 退路：截二维码区域的图
        rect = self.js("""(function(){
          var el = document.querySelector('.qrcode, [class*=qrcode]');
          if (!el) return '';
          var b = el.getBoundingClientRect();
          if (b.width < 40) return '';
          return JSON.stringify({x: b.x, y: b.y, w: b.width, h: b.height});
        })()""")
        try:
            box = json.loads(rect or "{}")
        except Exception:
            box = {}
        if not box:
            return ""
        r = self.send("Page.captureScreenshot", {
            "format": "png", "fromSurface": True,
            "clip": {"x": box["x"], "y": box["y"], "width": box["w"], "height": box["h"],
                     "scale": 2}}, timeout=30)
        data = (r.get("result") or {}).get("data") or ""
        return ("data:image/png;base64," + data) if data else ""

    def login_modal_open(self) -> bool:
        """登录弹窗还在 = 没登录（不导航的轻量检查）。"""
        try:
            return bool(self.js("!!document.querySelector('.login-modal, .login-container')"))
        except Exception:
            return True

    def logged_in(self) -> bool:
        """是否已登录：到搜索页上看——有登录弹窗=没登录，出现了笔记卡片=已登录。

        不能用 web_session cookie 判（匿名访客也有），也不能只看文字（小红书对未登录用户
        也会渲染部分结果）。
        """
        self.goto("https://www.xiaohongshu.com/search_result?keyword=%E9%A4%90%E9%A5%AE&type=51",
                  wait=3)
        for _ in range(12):
            try:
                if self.js("!!document.querySelector('.login-modal')"):
                    return False
                cards = int(self.js("document.querySelectorAll('section.note-item').length") or 0)
                if cards > 0:
                    return True
            except Exception:
                pass
            time.sleep(1)
        return False

    def scroll_bottom(self, times: int = 3, pause: float = 1.6):
        for _ in range(times):
            self.js("window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(pause)

    def close(self):
        try:
            self.ws.close()
        except Exception:
            pass
        self.proc.terminate()


def cmd_login(args):
    x = Xhs(profile=Path(args.profile), headless=False)
    try:
        x.goto("https://www.xiaohongshu.com/explore", wait=5)
        if x.logged_in():
            print("✓ 这个 profile 已经登录过了，无需重新扫码")
            return 0
        print("\n" + "=" * 62)
        print("请在弹出的浏览器窗口里用【小红书 App】扫码登录（或手机号登录）")
        print(f"最长等待 {args.minutes} 分钟…")
        print("=" * 62 + "\n")
        t0 = time.time()
        while time.time() - t0 < args.minutes * 60:
            if x.logged_in():
                print("✓ 登录成功，cookie 已保存到 profile，下次不用再扫")
                time.sleep(1)
                return 0
            time.sleep(2)
        print("✗ 超时未检测到登录（窗口还在，你可以再试；或者重跑本命令）")
        return 1
    finally:
        x.close()


def cmd_qr(args):
    """把小红书登录二维码交给网站用：

    持续等待（默认 5 分钟），期间把状态写进 JSON 文件（网页轮询它），
    登录成功就写 state=ok 并退出。浏览器是真实窗口但已最小化 —— 用户只看到网页里的二维码。
    """
    out = Path(args.out)

    def write(state: str, qr: str = "", note: str = "", expired: bool = False):
        payload = {"state": state, "at": datetime.now().isoformat(timespec="seconds")}
        if qr:
            payload["qr"] = qr
            if expired:
                # 保留上一张过期的码：网页不会突然空白，可以提示「正在自动换新」
                payload["qrExpired"] = True
        if note:
            payload["note"] = note
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        print(f"   状态: {state} {note}")

    x = Xhs(profile=Path(args.profile), headless=bool(getattr(args, "headless", False)),
            minimized=bool(getattr(args, "minimized", True)))
    try:
        try:
            logged = x.logged_in()
        except Exception as e:
            # 关键：失败也必须写成状态。以前异常直接抛出去、子进程静默退出，
            # 网页那边就永远停在「正在生成二维码…」（server.py 还把它当 starting）。
            write("error", note=f"连不上小红书页面（{type(e).__name__}）：{e}")
            return 1
        if logged:
            write("ok", note="已经登录过了")
            return 0
        x.goto("https://www.xiaohongshu.com/search_result?keyword=%E7%BE%8E%E9%A3%9F&type=51",
               wait=8)
        risk = x.risk_reason()
        if risk:
            write("blocked", note=risk)
            return 1
        if not x.login_modal_open():
            write("ok", note="已经登录过了")
            return 0
        qr = x.grab_qr()
        if not qr:
            x.goto("https://www.xiaohongshu.com/login", wait=7)
            qr = x.grab_qr()
        write("pending", qr, "二维码已生成" if qr else "没找到二维码元素")
        t0 = time.time()
        last_qr = qr
        while time.time() - t0 < args.wait:
            time.sleep(3)
            if not x.login_modal_open():
                # 弹窗没了还不够，得真的能看到搜索结果才算登录成功
                if x.logged_in():
                    write("ok", last_qr, "登录成功")
                    return 0
                print("   （弹窗关了但还没登录，继续等）")
            if int(time.time() - t0) % 30 < 3:
                fresh = x.grab_qr()
                if fresh and fresh != last_qr:
                    last_qr = fresh
                    write("pending", fresh)
        write("timeout", last_qr, "等待超时（保留上一张码，正在自动换新）", expired=True)
        return 1
    except Exception as e:
        write("error", note=f"{type(e).__name__}: {e}")
        return 1
    finally:
        x.close()


def cmd_status(args):
    """一次轻量探测，直接输出 JSON（网页/服务用它判断「现在能不能采集」）。"""
    out = {"state": "unknown", "loggedIn": False, "risk": "",
           "at": datetime.now().isoformat(timespec="seconds")}
    x = None
    try:
        x = Xhs(profile=Path(args.profile), minimized=True)
        try:
            ok = x.logged_in()
        except Exception as e:
            out.update(state="error", risk=f"{type(e).__name__}: {e}")
        else:
            risk = "" if ok else x.risk_reason()
            if ok:
                out.update(state="ok", loggedIn=True)
            elif risk:
                out.update(state="risk", risk=risk)
            else:
                out.update(state="need_login")
    finally:
        if x:
            x.close()
    write_status(out["state"], loggedIn=out["loggedIn"], risk=out["risk"])
    print(json.dumps(out, ensure_ascii=False))
    return 0


def cmd_logout(args):
    """清掉采集 profile 的登录态（cookie），让下一个人重新扫码。"""
    out = Path(args.out)
    ok = False
    x = None
    try:
        x = Xhs(profile=Path(args.profile), minimized=True)
        try:
            x.goto("https://www.xiaohongshu.com", wait=2)
        except Exception:
            pass
        r = x.send("Network.clearBrowserCookies")
        ok = "error" not in (r or {})
    finally:
        if x:
            x.close()
    payload = {"state": "logged_out",
               "at": datetime.now().isoformat(timespec="seconds"),
               "note": "已清除登录态，等下次扫码" if ok else "清 cookie 时出错"}
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    write_status("logged_out", note=payload["note"])
    print(json.dumps(payload, ensure_ascii=False))
    return 0 if ok else 1


def cmd_check(args):
    x = Xhs(profile=Path(args.profile), headless=bool(getattr(args, "headless", False)))
    try:
        ok = x.logged_in()
        print("登录状态：", "✓ 已登录" if ok else "✗ 未登录（先跑 python tools\\xhs.py login）")
        return 0 if ok else 1
    finally:
        x.close()


def _parse_like(s: str) -> int:
    s = (s or "").strip()
    m = re.match(r"([\d.]+)\s*(万)?", s)
    if not m:
        return 0
    n = float(m.group(1))
    return int(n * 10000) if m.group(2) else int(n)


def cmd_search(args):
    kws = [k.strip() for k in str(args.keywords).split(",") if k.strip()]
    out_path = Path(args.out)
    x = Xhs(profile=Path(args.profile), headless=bool(getattr(args, "headless", False)),
            minimized=bool(getattr(args, "minimized", True)))
    notes, blocked = [], False
    write_status("running", keywords=kws)
    try:
        x.goto("https://www.xiaohongshu.com/explore", wait=5)
        try:
            logged = x.logged_in()
        except Exception as e:
            print(f"✗ 访问小红书失败：{type(e).__name__}: {e}")
            write_status("error", note=f"{type(e).__name__}: {e}")
            return 0 if args.tolerant else 2
        if not logged:
            risk = x.risk_reason()
            if risk:
                print(f"✗ 被风控拦了：{risk}")
                print("   （拿到的不是登录墙而是风控页：等一会儿再试，并确认 xiaohongshu.com 走 DIRECT）")
                write_status("risk", note=risk, blocked=True)
            else:
                print("✗ 未登录：本机还没有有效登录态，已跳过采集")
                print("   （网页「小红书」分区里可以直接扫码；已经有人登录过就不需要再扫）")
                write_status("need_login", note="未登录，已跳过采集")
            if getattr(args, "require_login", False):
                return 3          # 3 = 未登录/被拦 —— 调用方据此标记「跳过」
            return 0 if args.tolerant else 2
        for kw in kws:
            print(f"搜索「{kw}」…")
            x.goto(SEARCH_URL.format(kw=urllib.parse.quote(kw)), wait=6)
            body = str(x.js("document.body.innerText") or "")
            risk = x.risk_reason()
            if risk:
                print(f"   ! {risk}")
                blocked = True
                break
            if "登录后查看" in body:
                print("   ! 出现登录弹窗（cookie 可能过期），先重新登录")
                blocked = True
                break
            x.scroll_bottom(args.scroll)
            raw = x.js(EXTRACT_JS)
            try:
                cards = json.loads(raw or "[]")
            except Exception:
                cards = []
            print(f"   抓到 {len(cards)} 张卡片")
            for c in cards[: args.per_keyword]:
                notes.append({
                    "title": (c.get("title") or "").strip(),
                    "author": (c.get("author") or "").strip(),
                    "like": _parse_like(c.get("like")),
                    "url": (c.get("url") or "").split("?")[0],
                    "keyword": kw,
                    "platform": "xiaohongshu",
                })
            write_status("running", keywords=kws, done=len(notes), current=kw)
            time.sleep(random.uniform(args.pause_min, args.pause_max))
    finally:
        x.close()

    # 去重 + 只留标题够长的
    seen, uniq = set(), []
    for n in notes:
        if not n["url"] or len(n["title"]) < 4 or n["url"] in seen:
            continue
        seen.add(n["url"])
        uniq.append(n)
    # 按采集顺序保留（平台自己的相关度排序），点赞只用于展示：
    # 按点赞重排会把「家庭烘焙教程」这类高赞内容顶到前面，反而不像品牌新品。
    uniq = [n for n in uniq]
    if blocked and not uniq and out_path.exists():
        # 被拦时不要把上一份好数据覆盖成空文件：digest 会悄悄少掉整个小红书分区，
        # 而网页面板会显示「已抓 0 条」，更难查。这里保留上一份并明确报出来。
        print(f"! 这次被拦且没抓到任何笔记，保留上一份 {out_path.name}（{out_path.stat().st_size} 字节）")
        write_status("risk", note="被拦且没抓到，保留上一份", blocked=True)
        return 0 if args.tolerant else 1
    payload = {
        "fetchedAt": datetime.now().isoformat(timespec="seconds"),
        "keywords": kws,
        "count": len(uniq),
        "notes": uniq,
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    write_status("ok", count=len(uniq), fetchedAt=payload["fetchedAt"], keywords=kws,
                 blocked=blocked)
    print(f"\n✓ 写入 {out_path}（{len(uniq)} 条，保留平台相关度顺序）")
    for n in uniq[:8]:
        print(f"   · [{n['like']:>6}赞] {n['title'][:40]}  @{n['author']}")
    return 0 if (blocked and args.tolerant) else (1 if blocked else 0)


def main():
    ap = argparse.ArgumentParser(description="小红书采集（真实浏览器 + 扫码登录一次）")
    ap.add_argument("--profile", default=str(DEFAULT_PROFILE))
    sub = ap.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("login", help="弹窗扫码登录")
    p1.add_argument("--minutes", type=int, default=6)
    p1.set_defaults(func=cmd_login)

    p2 = sub.add_parser("check", help="检查登录状态")
    p2.add_argument("--headless", action="store_true", help="无头模式（会被风控拦，仅调试用）")
    p2.set_defaults(func=cmd_check)

    p3 = sub.add_parser("search", help="按关键词抓笔记")
    p3.add_argument("--keywords", default="餐饮新品,茶饮新品")
    p3.add_argument("--per-keyword", type=int, default=12)
    p3.add_argument("--scroll", type=int, default=3)
    p3.add_argument("--days", type=int, default=10)
    p3.add_argument("--headless", action="store_true", default=False,
                    help="无头模式（会被风控拦，仅调试用；默认关 = 真实窗口 + 自动最小化）")
    p3.add_argument("--show-window", dest="minimized", action="store_false", default=True,
                    help="不自动最小化（想看窗口时用）")
    p3.add_argument("--pause-min", type=float, default=3.0,
                    help="关键词之间的最短间隔秒数（随机限速）")
    p3.add_argument("--pause-max", type=float, default=8.0,
                    help="关键词之间的最长间隔秒数（随机限速）")
    p3.add_argument("--require-login", action="store_true",
                    help="未登录/被风控时以退出码 3 结束（调用方据此标记「跳过」）")
    p3.add_argument("--tolerant", action="store_true",
                    help="未登录/被风控时不报错（退出 0），方便串进自动化流程")
    p3.add_argument("--out", default=str(ROOT / "public" / "data" / "xhs-notes.json"))
    p3.set_defaults(func=cmd_search)

    p4 = sub.add_parser("qr", help="把登录二维码输出给网站（真实窗口 + 自动最小化）")
    p4.add_argument("--wait", type=int, default=300, help="等多久（秒）")
    p4.add_argument("--headless", action="store_true", help="无头（不推荐，会被风控拦）")
    p4.add_argument("--show-window", dest="minimized", action="store_false", default=True,
                    help="不自动最小化（调试用）")
    p4.add_argument("--out", default=str(ROOT / "public" / "data" / "xhs-login.json"))
    p4.set_defaults(func=cmd_qr)

    p5 = sub.add_parser("status", help="输出登录/风控状态（JSON，给网页用）")
    p5.set_defaults(func=cmd_status)

    p6 = sub.add_parser("logout", help="清掉采集 profile 的登录态（换号用）")
    p6.add_argument("--out", default=str(ROOT / "public" / "data" / "xhs-login.json"))
    p6.set_defaults(func=cmd_logout)

    args = ap.parse_args()
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
