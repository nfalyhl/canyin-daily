# -*- coding: utf-8 -*-
"""小红书采集代理（方案 A：云端转发）——在「采集机」（机主自己的电脑）上常驻运行。

为什么需要它：
    小红书必须用「真实浏览器 + 家宽 IP」才不被风控，机房 IP 与无头浏览器都会被拦。
    所以公网页面只负责展示与下单，真正的活在**本机**干：

        网页（公网域名，需登录） ── /api/xhs/ask ──► EdgeOne 云函数（KV 存指令/状态/结果）
                                                        ▲            │
                                        /api/xhs/agent  │            │ 领取指令
                                                        └── 本机 xhs_agent.py ──► tools/xhs.py
                                                                       （真实 Edge + 家宽 IP）

用法（在项目根目录）：
    python tools\\xhs_agent.py                 # 常驻，每 5 秒一轮
    python tools\\xhs_agent.py --once          # 只跑一轮（调试）
    python tools\\xhs_agent.py --interval 10   # 自定义间隔
    python tools\\xhs_agent.py --no-notes      # 不上报采集结果（只同步状态）

开机自启（可选）：把下面这行丢进「任务计划程序」或启动文件夹
    pythonw "C:\\Users\\Lenovo\\Desktop\\代码\\canyin-daily\\tools\\xhs_agent.py"

硬约束：
    · 必须已经跑过 tools\\auth_admin.py set-auth https://<新域名>（云端地址从 auth-config.json 读）
    · config\\auth_admin_token.txt 里的 ADMIN_TOKEN 必须和云端环境变量一致
    · 采集前必须有登录态（没有就由网页上的人扫码；已经有人登录过就不用再扫）
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
try:  # 控制台默认 GBK，中文日志会乱码
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
DATA = ROOT / "public" / "data"
LOGIN_FILE = DATA / "xhs-login.json"      # tools/xhs.py qr   写入（含二维码 dataURL）
STATUS_FILE = DATA / "xhs-status.json"    # tools/xhs.py status/search 写入
NOTES_FILE = DATA / "xhs-notes.json"      # tools/xhs.py search 写入
KW_FILE = ROOT / "config" / "xhs_keywords.txt"
LOG_FILE = ROOT / "logs" / "xhs-agent.log"
PY = sys.executable
DEFAULT_KEYWORDS = "餐饮新品,茶饮新品,咖啡新品,甜品店上新"


def log(msg: str) -> None:
    """写日志。

    被计划任务用 pythonw.exe 拉起时**没有控制台**（sys.stdout 是 None），
    print 会直接抛异常，所以两个出口都包住：控制台能给就给，同时一律落盘，
    这样「开机自启」之后出问题也有 logs\\xhs-agent.log 可查。
    """
    line = f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"
    try:
        print(line, flush=True)
    except Exception:
        pass
    try:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        if LOG_FILE.exists() and LOG_FILE.stat().st_size > 2 * 1024 * 1024:
            LOG_FILE.write_text("", encoding="utf-8")
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def read_json(p: Path, default=None):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def read_secret(p: Path) -> str:
    """读密钥文件：跳过注释/空行，取最后一个非注释行（兼容 KEY=VALUE 写法）。"""
    if not p.exists():
        return ""
    val = ""
    for ln in p.read_text(encoding="utf-8", errors="replace").splitlines():
        s = ln.strip()
        if not s or s.startswith("#"):
            continue
        if "=" in s and s.split("=", 1)[0].strip().upper() in ("ADMIN_TOKEN", "TOKEN"):
            s = s.split("=", 1)[1].strip()
        val = s.strip().strip('"').strip("'")
    return val


def base_and_token() -> tuple[str, str]:
    cfg = read_json(ROOT / "public" / "auth-config.json", {}) or {}
    base = str(cfg.get("authBase") or "").rstrip("/")
    tok = read_secret(ROOT / "config" / "auth_admin_token.txt")
    return base, tok


def keywords() -> str:
    if KW_FILE.exists():
        raw = KW_FILE.read_text(encoding="utf-8")
        ks = [x.strip() for x in raw.replace("\n", ",").split(",") if x.strip() and not x.startswith("#")]
        if ks:
            return ",".join(ks)
    return DEFAULT_KEYWORDS


def local_state() -> dict:
    login = read_json(LOGIN_FILE, {}) or {}
    status = read_json(STATUS_FILE, {}) or {}
    notes = read_json(NOTES_FILE, {}) or {}
    return {
        "loggedIn": login.get("state") == "ok" or status.get("state") == "ok",
        "loginState": login.get("state") or "",
        "qr": login.get("qr") or "",          # data:image/png;base64,...
        "qrAt": login.get("at") or "",
        "loginNote": login.get("note") or "",
        "collectState": status.get("state") or "",
        "note": status.get("note") or "",
        "risk": status.get("risk") or "",
        "blocked": bool(status.get("blocked")),
        "lastCollectAt": notes.get("fetchedAt") or "",
        "keywords": notes.get("keywords") or [],
        "count": int(notes.get("count") or 0),
        "collectedOn": notes.get("fetchedAt") or "",
        "agent": str(Path.home()).split("\\")[-1],
        "agentAt": datetime.now().isoformat(timespec="seconds"),
    }


OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # 一律直连


def post(url: str, payload: dict, timeout: int = 40):
    """上报到云端。

    **强制直连**：这台机器的系统代理指向 127.0.0.1:7897，但 Clash 的内核经常没在跑，
    端口没人监听 —— 于是所有“按系统代理走”的请求会随机报握手超时 / RemoteDisconnected，
    排查时特别唬人（报错看上去像云端挂了）。我们的域名本来就是为了国内直连才迁到
    EdgeOne 海外区的，所以这里直接绕开系统代理，一次就稳（实测直连 6/6 成功）。
    """
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST",
                                 headers={"Content-Type": "application/json",
                                          "User-Agent": "canyin-xhs-agent/1.0",
                                          "Cache-Control": "no-store"})
    try:
        with OPENER.open(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        body = e.read(300).decode("utf-8", "replace")
        log(f"× 云端返回 {e.code}：{body[:200]}")
        return None
    except Exception as e:
        log(f"× 连不上云端：{type(e).__name__}: {e}")
        return None


def run_xhs(args: list[str], timeout: int = 600) -> int:
    """跑一个 tools/xhs.py 子命令。

    关键点：**把子进程输出捕获回来写进日志**。
    代理被计划任务用 pythonw.exe 拉起时没有控制台，子进程的 traceback 会直接丢掉，
    于是只能看到「退出码 1」这样的哑谜——早期排查这个问题就卡在这里。
    """
    cmd = [PY, "-u", str(ROOT / "tools" / "xhs.py")] + args
    log("→ " + " ".join(cmd[2:]))
    log(f"   解释器：{PY}")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0
    try:
        p = subprocess.run(cmd, cwd=str(ROOT), timeout=timeout, creationflags=flags,
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        log("× 子命令超时")
        return -1
    for ln in (p.stdout or "").strip().splitlines()[-14:]:
        log("   | " + ln)
    if p.returncode != 0:
        for ln in (p.stderr or "").strip().splitlines()[-12:]:
            log("   ! " + ln)
    return p.returncode


def run_cmd(base: str, cmd: dict) -> None:
    """[已废弃] 同步执行指令。现在统一用 start_cmd() 异步跑。"""
    start_cmd(cmd)


# 一种动作同时只跑一个；跑着的时候上报不能停（否则二维码回传不出去）
RUNNING: dict[str, float] = {}
DONE_ACK: list[str] = []          # 已执行完、等下轮上报时告诉云端的 cmd id
ROUNDS: dict[str, int] = {}       # login 自动换新了几轮
MAX_LOGIN_ROUNDS = 4              # 换新 4 轮（约 15 分钟）还没扫就停下来，避免无限开浏览器

CMD_ARGS = {
    "login": lambda: ["qr", "--wait", "240", "--out", str(LOGIN_FILE)],
    "logout": lambda: ["logout", "--out", str(LOGIN_FILE)],
    "collect": lambda: ["search", "--keywords", keywords(), "--require-login",
                        "--tolerant", "--out", str(NOTES_FILE)],
}
CMD_TIMEOUTS = {"login": 330, "logout": 200, "collect": 900}


def _watch(action: str, cmd_id: str, p) -> None:
    """等子进程结束，把输出写日志，并登记「可以告诉云端这条指令已完成」。"""
    try:
        out, _ = p.communicate(timeout=CMD_TIMEOUTS.get(action, 900))
    except subprocess.TimeoutExpired:
        p.kill()
        out = "（超时被杀）"
    for ln in (out or "").strip().splitlines()[-14:]:
        log("   | " + ln)
    log(f"{action} 结束（退出码 {p.returncode}）")
    ack = True
    if action == "login" and not local_state().get("loggedIn"):
        # 登录还没成：**不 ack**，让云端 90 秒后重发 → 二维码自动换新
        # （就像小红书自己的登录页那样，码过期了自动刷一张新的，而不是留个白屏）
        ROUNDS[action] = ROUNDS.get(action, 0) + 1
        if ROUNDS[action] >= MAX_LOGIN_ROUNDS:
            log(f"  已经自动换新 {ROUNDS[action]} 轮仍未扫码成功，先停下来（再点一次「扫码登录」可继续）")
            ROUNDS[action] = 0
        else:
            ack = False
            log(f"  登录还没完成 → 保留指令，云端稍后会让我再生成一张新码（第 {ROUNDS[action]} 轮）")
    if cmd_id and ack:
        DONE_ACK.append(cmd_id)
    RUNNING.pop(action, None)


def start_cmd(cmd: dict) -> None:
    """执行云端下发的指令（**异步**）。

    为什么必须异步：`xhs.py qr` 要开着浏览器等扫码，最多跑 240 秒。
    以前这里是同步 subprocess.run，这 4 分钟里主循环完全停住 ——
    二维码在本地生成、却一次也没上报给云端，等恢复上报时文件已经被
    「等待超时」覆盖了。网页因此永远看不到码（2026-10-01 实测）。
    改成 Popen + 看护线程：主循环照常每几秒上报，二维码一落地就传上云。
    """
    action = str(cmd.get("action") or "")
    cmd_id = str(cmd.get("id") or "")
    log(f"领取指令：{action}（来自 {cmd.get('by')}）")
    if action not in CMD_ARGS:
        log(f"× 不认识的指令：{action}")
        return
    if action in RUNNING:
        log(f"  已有一个 {action} 在跑（{int(time.time() - RUNNING[action])}s），跳过重复执行")
        return
    c = [PY, "-u", str(ROOT / "tools" / "xhs.py")] + CMD_ARGS[action]()
    log("→ " + " ".join(c[2:]))
    log(f"   解释器：{PY}（异步执行：跑的过程中上报不停，二维码一生成就能回传网页）")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0
    p = subprocess.Popen(c, cwd=str(ROOT), creationflags=flags,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, encoding="utf-8", errors="replace")
    RUNNING[action] = time.time()
    threading.Thread(target=_watch, args=(action, cmd_id, p), daemon=True).start()


def cycle(base: str, token: str, push_notes: bool, last_done: str) -> str:
    """跑一轮：上报状态（+结果）→ 领指令 → 异步执行。"""
    state = local_state()
    payload: dict = {"adminToken": token, "state": state}
    notes = read_json(NOTES_FILE, {}) or {}
    if push_notes and notes.get("notes"):
        payload["notes"] = notes["notes"]
        payload["notesMeta"] = {"fetchedAt": notes.get("fetchedAt"), "keywords": notes.get("keywords"),
                                "count": notes.get("count")}
    done = DONE_ACK.pop(0) if DONE_ACK else (last_done or "")
    if done:
        payload["cmdDone"] = done
    r = post(base + "/api/xhs/agent", payload)
    if not r:
        return ""
    log(f"已上报：登录={state['loggedIn']} 采集={state['collectState'] or '-'} "
        f"条数={state['count']} 有码={'是' if state.get('qr') else '否'}")
    cmd = r.get("cmd")
    if cmd:
        start_cmd(cmd)
    return ""


def single_instance_guard(port: int = 49513):
    """单实例锁。

    为什么要：这个代理会被「计划任务开机自启」拉起，也可能被人手动跑。
    两个实例一起轮询会抢同一条云端指令、还会抢同一个浏览器 profile，
    到时候两个 xhs.py 撞车很难排查。占住一个本地端口当锁最简单可靠。
    """
    import socket
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", port))
        s.listen(1)
        return s
    except OSError:
        try:
            s.close()
        except Exception:
            pass
        return None


def collected_today() -> bool:
    """今天采过没有（看 xhs-notes.json 的 fetchedAt 日期）。"""
    notes = read_json(NOTES_FILE, {}) or {}
    at = str(notes.get("fetchedAt") or "")
    return bool(at) and at[:10] == datetime.now().strftime("%Y-%m-%d")


def catch_up() -> None:
    """启动时补采。

    为什么需要：采集机（机主的电脑）关机/重启后，代理才会被重新拉起，
    而每天那次定时采集很可能在它没开机时错过了。有登录态时开机即补一次，
    这样「昨晚关机 → 今早开机」不用人工干预。
    """
    st = local_state()
    if not st["loggedIn"]:
        log("启动补采：还没有登录态，跳过（先在网页里扫码登录）")
        return
    if collected_today():
        log(f"启动补采：今天已采集过（{st.get('lastCollectAt')}），跳过")
        return
    log("启动补采：今天还没采集过 → 立刻采一次")
    rc = run_xhs(["search", "--keywords", keywords(), "--require-login", "--tolerant",
                  "--out", str(NOTES_FILE)], timeout=900)
    log(f"启动补采结束（退出码 {rc}）")


def main() -> int:
    ap = argparse.ArgumentParser(description="小红书采集代理（云端转发）")
    ap.add_argument("--once", action="store_true", help="只跑一轮")
    ap.add_argument("--interval", type=float, default=5.0, help="轮询间隔秒（默认 5）")
    ap.add_argument("--no-notes", action="store_true", help="不上报采集结果，只同步状态")
    ap.add_argument("--no-catchup", action="store_true", help="启动时不自动补采")
    args = ap.parse_args()

    base, token = base_and_token()
    if not base or not token:
        log("× 缺配置：authBase（public/auth-config.json）或 ADMIN_TOKEN（config/auth_admin_token.txt）")
        return 2
    guard = single_instance_guard()
    if guard is None:
        log("已经有一个采集代理在跑了（本地锁端口 49513 被占），本进程直接退出，不重复干活")
        return 0
    log(f"云端：{base}；采集关键词：{keywords()}")
    log(f"采集机：{Path.home().name}；本进程参与「网页下单 → 本机采集」")
    try:
        if not args.no_catchup:
            catch_up()
    except Exception as e:
        log(f"× 启动补采异常（忽略）：{type(e).__name__}: {e}")
    last_done = ""
    while True:
        try:
            last_done = cycle(base, token, not args.no_notes, last_done) or ""
        except KeyboardInterrupt:
            log("收到 Ctrl+C，退出")
            return 0
        except Exception as e:
            log(f"× 本轮异常：{type(e).__name__}: {e}")
        if args.once:
            return 0
        time.sleep(max(2.0, args.interval))


if __name__ == "__main__":
    sys.exit(main())
