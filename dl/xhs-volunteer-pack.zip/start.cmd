﻿@echo off
chcp 65001 >nul
title 餐饮日报-小红书采集机（志愿版）
cd /d "%~dp0"
echo ============================================
echo  餐饮日报 · 小红书采集机（志愿版）
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo [x] 没找到 Python。请先安装 Python 3.10 及以上：
  echo     https://www.python.org/downloads/
  echo     安装时一定要勾上 "Add python.exe to PATH"，然后重新双击本文件。
  echo.
  echo     详细步骤见同目录的 README.txt
  echo.
  pause
  exit /b 1
)

python -c "import websocket" >nul 2>nul
if errorlevel 1 (
  echo [*] 第一次运行，正在安装依赖 websocket-client ...
  python -m pip install --quiet --disable-pip-version-check websocket-client -i https://pypi.tuna.tsinghua.edu.cn/simple
  if errorlevel 1 (
    echo [x] 依赖安装失败（多半是网络）。可以手动执行：
    echo     python -m pip install websocket-client -i https://pypi.tuna.tsinghua.edu.cn/simple
    echo.
    pause
    exit /b 1
  )
  echo [*] 依赖装好了。
)

echo [*] 启动采集代理（这个窗口不要关；关掉就等于离线）
echo     浏览器会在后台隐身工作，二维码会传到网页上给你扫。
echo.
python -u tools\xhs_agent.py --interval 5
echo.
echo [*] 代理已退出。按任意键关闭本窗口。
pause
